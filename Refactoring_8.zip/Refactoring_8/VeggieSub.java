public class VeggieSub extends Sandwich{

    boolean customerWantsMeat(){ return false; }

    void addMeat() {

    }

    void addCondiments() {

        System.out.println("Vinegar and Oil Added");

    }

}
