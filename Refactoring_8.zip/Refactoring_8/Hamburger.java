public class Hamburger extends Sandwich{

    void addMeat() {

        System.out.println("Hamburger Added");

    }

    void addCondiments() {

        System.out.println("Special Sauce Added");

    }

}
