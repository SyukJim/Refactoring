interface Visitable {
  
  public double accept(Visitor visitor);
  
}